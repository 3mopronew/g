//══════[ Package ]══════

module.exports = function ({ Client, RichPresence, joinVoiceChannel, config }) {

//══════[ Login ]══════

const client = new Client({ checkUpdate: false })

client.login("MTA4NjU2NjgyMzQ1MDkxNDgxNg.G7kwHS.5OJUXkSwR3w6jGkDkshwzN2EUA6-tVd47spMc0").catch(() => console.error("❌ ㆍ TOKEN", __filename))

//══════[ Code ]══════

client.on("ready", () => {
const activity = new RichPresence()
.setApplicationId(config.app)
.setURL(config.url)
.setType("STREAMING")
.setName("VALORANT")
.setDetails("VALORANT")
.setStartTimestamp(Date.now())
.setAssetsLargeImage("https://cdn.discordapp.com/emojis/1216720364177068074.png")
client.user.setActivity(activity)
client.user.setPresence({ status: "online" })})

client.on("ready", () => {
//client.user.setStatus("invisible")
setInterval(() => {
try {
const channel = client.channels.cache.get("1230520452301197478")
if (!channel) console.error("❌ ㆍ Voice Channel", __filename)
const VoiceConnection = joinVoiceChannel({
channelId: channel.id,
guildId: "1230520451852140544",
selfMute: true,
selfDeaf: false,
adapterCreator: channel.guild.voiceAdapterCreator })
} catch (error) {
console.error("❌ ㆍ No Voice Permission", __filename)}}, config.time )})

}