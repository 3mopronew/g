//══════[ Package ]══════

module.exports = function ({ Client, RichPresence, joinVoiceChannel, config }) {

//══════[ Login ]══════

const tokens = [

"MTMwMDcxMTMyNDM4MDMwMzQ1MA.Gtua8r.5nQnvpBYvp3FtAIGIHMdaAkPoJwYdddU9wt2ac", // @1.g.8
"MTMwMjk5MjU1MTkyNTc4MDQ5Mw.GReUwb.n3O58VohWFGGl4cupbaRGrpiAVim0MEO04uZY0", // @vvv.1.
"MTMwMTgzMDY2NDI5NDc2NDU3NQ.GhjeLx.MEZB_I_DEF6pNqdCCsmCL0nx5NuENzu_bPdYnU", // @.ooy.
"MTMwMTg0MDI3NjQ0ODM0NjEyNA.GqtG0z.IQyHPmZnqsFmppSrdMVZ2j1EwZgtbyVOJm7t9U", // @_ktyy
"MTMwMTg0MjQ0Nzc5NzU4Mzk2Mg.GrEjKw.ldn7b3AEn0KRYGETpVfBZU9zgn8VCCTSyefpJI" // @rh4f

]

function createBot(token) {

const client = new Client({ checkUpdate: false })

client.on("ready", () => {
client.user.setStatus("dnd")
setInterval(() => {
try {
const channel = client.channels.cache.get(config.channel)
if (!channel) console.error("❌ ㆍ Text Channel", __filename)
channel.send(config.message)
} catch (error) {
console.error("❌ ㆍ No Text Permission", __filename)}}, config.time )})

client.login(token).catch(() => console.error(`❌ ㆍ ${token}`, __filename))}

tokens.forEach(token => createBot(token))

}