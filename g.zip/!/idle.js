//══════[ Package ]══════

module.exports = function ({ Client, RichPresence, joinVoiceChannel, config }) {

//══════[ Login ]══════

const tokens = [

"ODkzNjA5MTg4MDE2NjY4NzEy.GQBDTP.vLHhaj3UaoUTzxjQer8I8_bsQhy_85QVkEVkhI", // @onlyahmd

//══════════════════════════════════════════════════

"OTMwMTY3MTI0NjEyMjMxMjM5.G1x0mU.Eyb5M5OYRkmjFl5hl2cpl6SQwQ5ZhNpXOXCMn4", // @alnqeeb
"MTMwMTgzMDY2NDI5NDc2NDU3NQ.GhjeLx.MEZB_I_DEF6pNqdCCsmCL0nx5NuENzu_bPdYnU", // @shehabrip
"OTMyMjQ1NjU5MTI0MzY3NDQx.GX5L6_.IigRh2nw7xHpMHsw9tfhVyKmKXgmY00LiIovlA", // @olloollo
"OTMyMjU2NTY1MzMzOTkxNDU0.GqeM9Q.vEEbjJVuYDXen35FlVmHD7NdrC-wfWd_F5wDMc", // @5njjr
"OTMyMjQ4MzE5ODY1MDA4MTI4.GgWyu9.OpLnl1fOf5sD3eAjOrS8Rjc43kkwzKIzKj1JJQ", // @eeh88

//══════════════════════════════════════════════════

"MTMwOTAxNzc0NTc2MDk4MDk5Mw.GpG5P3.zIb7oXZ-ALglHfowu0cfw1OcgHcV-LmeNJTEgw", // @ke_oky
"MTI5OTE5MTE5OTQ5MTQyODQ0Ng.GCnUq1.BPxCuOyeH7MkZYnzczlrDMiUm6w8a77eTEdg8o", // @f6.y.
"MTI5OTE5MzI5MTM2NzI1MjAwOQ.G0-YDE.Ga58Qw2gSQfJvUw6J8LUnR8vENH9Pv2jhKUJik", // @1.q_q
"MTI5OTYxMjU2MzA1MDMzMjIxMA.G9qMiJ.MUdBvsttFlBW8huHzrn29QrRHXLGd3Im2Pc8dU", // @96.ii.
"MTI5OTczMzU0NjU3NTA2OTIyNA.G-l_sX.OTJ9vmIcp74bglFZuZ_0t_gr179cJ18IsJuYY0" // @qy_s.

]

function createBot(token) {

const client = new Client({ checkUpdate: false })

client.on("ready", () => {
client.user.setStatus("idle")
setInterval(() => {
try {
const channel = client.channels.cache.get(config.channel)
if (!channel) console.error("❌ ㆍ Text Channel", __filename)
channel.send(config.message)
} catch (error) {
console.error("❌ ㆍ No Text Permission", __filename)}}, config.time )})

client.login(token).catch(() => console.error(`❌ ㆍ ${token}`, __filename))}

tokens.forEach(token => createBot(token))

}