//══════[ Package ]══════

module.exports = function ({ Client, RichPresence, joinVoiceChannel, config }) {

//══════[ Login ]══════

const client = new Client({ checkUpdate: false })

client.login("MTM1MjUyNTczNDI0OTQ5NjU4Ng.Gpb40Q.fxWK_oXuq7r4id8F_mPgSN-NxdDYVFVSuYhwlw").catch(() => console.error("❌ ㆍ TOKEN", __filename))

//══════[ Code ]══════

client.on("ready", () => client.user.setActivity("ㅤ", { type: "STREAMING", url: config.url }))

}